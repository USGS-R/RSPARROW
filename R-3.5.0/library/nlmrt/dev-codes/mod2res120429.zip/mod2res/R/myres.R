myres <-function(prm, ...) {
     stop("This is a dummy function")
}
